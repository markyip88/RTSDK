package com.refinitiv.ema.unittest;

public final class TestDictionaries {
	public static String fieldDictionaryFileName = "./src/test/resources/com/refinitiv/ema/unittest/DataDictionaryTest/RDMTestDictionary";
	public static String enumTableFileName = "./src/test/resources/com/refinitiv/ema/unittest/DataDictionaryTest/testenumtype.def";
	
}
